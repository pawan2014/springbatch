package com.mebatch.kdp;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableBatchProcessing
public class KdpApplication {

	public static void main(String[] args) {
		// SpringApplication.run(KdpApplication.class, args);
		System.exit(SpringApplication.exit(SpringApplication.run(KdpApplication.class, args)));

	}

}
