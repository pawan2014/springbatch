package com.mebatch.kdp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KdpApplicationTests {

	@Test
	void contextLoads() {
	}

}
